#include "main.h"
#include "tim.h"
#include "usart.h"
#include "stdio.h"

#define task_out 0
#define task_in 1

uint8_t mpu6050_data[11];
uint8_t pwm_data[3];
int pwm_int=265; 
float roll,pitch;
short rollH,rollL,pitchH,pitchL;
char roll_pitch[40];
float mg90s1,mg90s2,mg90s1_change,mg90s2_change;
float a=100;
int p=50;

struct task_information
{
	int in_out;
	int flag;	
	int time;
};

struct task_information tsak1_information = {task_in,0,1};
struct task_information tsak2_information = {task_out,0,10};
struct task_information tsak3_information = {task_out,0,1};

void change_flag()
{
	static int now_time = 0;
	now_time++;
	if (now_time == 1001) now_time = 1;
	if (now_time % tsak1_information.time == 0) tsak1_information.flag = 1;
	if (now_time % tsak2_information.time == 0) tsak2_information.flag = 1;
	if (now_time % tsak3_information.time == 0) tsak3_information.flag = 1;
}

void run_function()
{
	if (tsak1_information.in_out&&tsak1_information.flag)
	{
		task1();
		tsak1_information.in_out = task_out;
		tsak2_information.in_out = task_in;
		tsak3_information.in_out = task_in;
		
		tsak1_information.flag = 0;
	}
	if (tsak2_information.in_out&&tsak2_information.flag)
	{
		task2();
		
		tsak2_information.flag = 0;
	}
	if (tsak3_information.in_out&&tsak3_information.flag)
	{
		task3();
		
		tsak3_information.flag = 0;
	}
}

void task1()
{
	mg90s1=270;
	mg90s2=255;
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_3); 
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4); 
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3,mg90s1);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4,mg90s2);
	HAL_UART_Receive_DMA(&huart2,mpu6050_data,sizeof(mpu6050_data));
	HAL_UART_Receive_DMA(&huart1,pwm_data,sizeof(pwm_data));
}

void task2()
{
	mg90s1_change = pid(0,pitch,0.09,0.00125,1.5,0);
	mg90s2_change = pid(0,roll,0.09,0.00125,1.5,1);
	mg90s1 = mg90s1 + mg90s1_change;
	mg90s2 += mg90s2_change;
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3,(int)mg90s1);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4,(int)mg90s2);
}

void task3()
{
	
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance==USART2)
	{
		redata_MPU(mpu6050_data);
		sprintf(roll_pitch,"   roll=%f   pitch=%f   ",roll,pitch);
		HAL_UART_Transmit_DMA(&huart1,roll_pitch,sizeof(roll_pitch));
	}
	if(huart->Instance==USART1)
	{
		p = atoi(pwm_data);
		HAL_UART_Transmit_DMA(&huart1,pwm_data,sizeof(pwm_data));
	}
}

void redata_MPU(uint8_t chrTemp[11])
{
	if(chrTemp[0] == 0x55)
	{
		if(chrTemp[1] == 0x53)
		{
			rollH = chrTemp[3];
			rollL = chrTemp[2];
			pitchH = chrTemp[5];
			pitchL = chrTemp[4];
			roll = (rollH<<8|rollL)/32768.0*180;
			pitch = (pitchH<<8|pitchL)/32768.0*180;
			if(roll>180) roll-=360;
			if(pitch>180) pitch-=360;
		}
	}
}

//int ftoi(float a)
//{
//	
//}

