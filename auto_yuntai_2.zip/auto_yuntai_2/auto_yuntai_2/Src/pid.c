#include "main.h"

#define memory 20

float pid (float hope,float observe,float vkp,float vki,float vkd,int id)
{
	static float error[20][memory];
	float out = 0,p,i,d;
	static int location[10];
	int lastlocation;
	lastlocation = location[id];
	location[id]++;
	if(location[id]==memory) location[id] = 0;
	error[id][location[id]] = hope - observe;
	p = error[id][location[id]] * vkp;
	i = 0;
	for(int j = 0;j < memory;j++)
	{
		i += error[id][j];
	}
	i *= vki;
	d = (error[id][location[id]] - error[id][lastlocation]) * vkd;
	out = p + i + d;
	return out;
}


float cascade_pid (float location_hope,float location_observe,float speed_observe,float vkp[2],float vki[2],float vkd[2],int id)
{
	float speed_hope,out;
	speed_hope = pid(location_hope,location_observe,vkp[0],vki[0],vkd[0],id);
	out = pid(speed_hope,speed_observe,vkp[1],vki[1],vkd[1],id + 10);
	return out;
}





